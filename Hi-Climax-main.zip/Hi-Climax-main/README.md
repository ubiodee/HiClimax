## This site is hosted on hiclimax.netlify.app

## It is built with HTML, CSS, and Vanilla JavaScript.

## The layout was designed using CSS Flexbox and Grid. It is a single page web design.

## The full site is uploaded on this day: April 16, 2022.
